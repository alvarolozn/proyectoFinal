import java.util.Random;
import javax.swing.JOptionPane;

public class proyecto {
    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        new proyecto().run();
    }

    int n;
    int[][] laberinto;
    int inicioX, inicioY, finX, finY;
    int caminosTrampa;
    
    public void run() {
        try {
            String inputN = JOptionPane.showInputDialog("Digite el número de filas y columnas del laberinto (debe ser mayor o igual a 2):");
            n = Integer.parseInt(inputN);
            if (!validarTamaño(n)) {
                JOptionPane.showMessageDialog(null, "El tamaño debe ser mayor o igual a 2. Inténtelo nuevamente.");
                return;
            }

            String inputInicioX = JOptionPane.showInputDialog("Digite la coordenada de inicio en X:");
            inicioX = Integer.parseInt(inputInicioX);
            String inputInicioY = JOptionPane.showInputDialog("Digite la coordenada de inicio en Y:");
            inicioY = Integer.parseInt(inputInicioY);
            if (!validarCoordenadas(inicioX, n) || !validarCoordenadas(inicioY, n)) {
                JOptionPane.showMessageDialog(null, "Las coordenadas deben estar en las fronteras del laberinto. Inténtelo nuevamente.");
                return;
            }

            String inputFinX = JOptionPane.showInputDialog("Digite la coordenada de fin en X:");
            finX = Integer.parseInt(inputFinX);
            String inputFinY = JOptionPane.showInputDialog("Digite la coordenada de fin en Y:");
            finY = Integer.parseInt(inputFinY);
            if (!validarCoordenadas(finX, n) || !validarCoordenadas(finY, n)) {
                JOptionPane.showMessageDialog(null, "Las coordenadas deben estar en las fronteras del laberinto. Inténtelo nuevamente.");
                return;
            }

            laberinto = new int[n][n];
            caminosTrampa = n;

            int rest = Integer.parseInt(JOptionPane.showInputDialog("Digite 1 si quiere ver el camino y 2 si quiere Jugar"));
            if (rest == 1) {
                generarCaminoAleatorio(laberinto, finX, finY, inicioX, inicioY);
            } else {
                generarCaminoAleatorio(laberinto, finX, finY, inicioX, inicioY);
                generarCaminoTrampa(laberinto, n, finX, finY, caminosTrampa, 0);
            }

            // Imprimir el laberinto
            montrarLaberintoRecursivo(laberinto, n, 0, 0);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ingrese un número válido. Inténtelo nuevamente.");
        }
    }

    /**
     * se llena el laberinto de ceros
     * @param laberinto matriz
     * @param n dimension
     * @param i fila
     * @param j columna
     */
    public static void inicioLaberintoRecursivo(int laberinto[][], int n, int i, int j) {
        if (i < n) {
            if (j < n) {
                laberinto[i][j] = 0;
                inicioLaberintoRecursivo(laberinto, n, i, j + 1);
            } else {
                inicioLaberintoRecursivo(laberinto, n, i + 1, 0);
            }
        }
    }

    /**
     *  muestra el laberinto
     * @param laberinto
     * @param n
     * @param i
     * @param j
     */
    public static void montrarLaberintoRecursivo(int laberinto[][], int n, int i, int j) {
        if (i < n) {
            if (j < n) {
                System.out.print(laberinto[i][j] + "|");
                montrarLaberintoRecursivo(laberinto, n, i, j + 1);
            } else {
                System.out.println(" ");
                montrarLaberintoRecursivo(laberinto, n, i + 1, 0);
            }
        }
    }

    /**
     * realiza el camino desde las coordenadas de inicio hasta las coordenadas finales
     * @param laberinto
     * @param finX
     * @param finY
     * @param x
     * @param y
     */
    static void generarCaminoAleatorio(int[][] laberinto, int finX, int finY, int x, int y) {
        Random random = new Random();

        if (x == finX && y == finY) {
            return;
        }

        if (random.nextBoolean()) {
            x = (x < finX) ? x + 1 : x - 1;
        } else {
            y = (y < finY) ? y + 1 : y - 1;
        }

        laberinto[y][x] = 1;

        generarCaminoAleatorio(laberinto, finX, finY, x, y);
    }

    /**
     * genera caminos que te pueden desviar de tu destino
     * @param laberinto
     * @param n
     * @param finX
     * @param finY
     * @param caminosTrampa
     * @param j
     */
    void generarCaminoTrampa(int[][] laberinto, int n, int finX, int finY, int caminosTrampa, int j) {
        if (j < caminosTrampa) {
            int x = new Random().nextInt(n);
            int y = new Random().nextInt(n);

            while (x == finX && y == finY) {
                x = new Random().nextInt(n);
                y = new Random().nextInt(n);
            }

            for (int i = 0; i < n; i++) {
                laberinto[y][x] = 1;

                int direccion = new Random().nextInt(4);

                switch (direccion) {
                    case 0:
                        y = Math.max(0, y - 1);
                        break;
                    case 1:
                        y = Math.min(n - 1, y + 1);
                        break;
                    case 2:
                        x = Math.max(0, x - 1);
                        break;
                    case 3:
                        x = Math.min(n - 1, x + 1);
                        break;
                }
            }
            generarCaminoTrampa(laberinto, n, finX, finY, caminosTrampa, j + 1);
        }
    }

    /**
     * validaciones tamaño matriz
     * @param n
     * @return
     */
    public static boolean validarTamaño(int n) {
        return n >= 2;
    }

    /**
     * validaciones coordenadas en la frontera de la matriz
     * @param coord
     * @param n
     * @return
     */
    public static boolean validarCoordenadas(int coord, int n) {
        return coord == 0 || coord == n - 1;
    }
}

